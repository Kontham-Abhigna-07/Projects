from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image
import io

app = FastAPI()

# Enable CORS if accessing from frontend on different port
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    # Dummy prediction logic for test
    contents = await file.read()
    image = Image.open(io.BytesIO(contents))

    # Simulate prediction
    return {"class": "Organic Waste", "confidence": 0.94}
