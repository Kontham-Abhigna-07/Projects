import streamlit as st
import requests
from PIL import Image
import io

# Waste category mapping
CATEGORY_MAP = {
    "glass": "Recyclable – Glass",
    "cardboard": "Recyclable – Cardboard",
    "paper": "Recyclable – Paper",
    "metal": "Recyclable – Metal",
    "plastic": "Recyclable – Plastic",
    "trash": "General Waste – Trash",
    "organic": "Organic Waste",
    "food": "Organic Waste",
    "biodegradable": "Organic Waste",
    "battery": "Hazardous Waste",
    "clothes": "Textile Waste"
}

# Streamlit UI
st.set_page_config(page_title="Waste Classification", layout="centered")
st.title("♻ Waste Management System")
st.markdown("Upload an image of waste and click the button to identify its type.")

# Upload image
uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    # Display uploaded image
    image = Image.open(uploaded_file)
    st.image(image, caption="Uploaded Image", use_container_width=True)

    # Predict button
    if st.button("🧠 Predict Waste Type"):
        # Convert image to bytes
        image_bytes = io.BytesIO()
        image.save(image_bytes, format='PNG')
        image_bytes.seek(0)

        st.markdown("### 🔄 Sending to model for prediction...")

        try:
            response = requests.post(
                "http://localhost:8000/predict",
                files={"file": ("filename.png", image_bytes, "image/png")}
            )

            if response.status_code == 200:
                try:
                    result = response.json()
                    predicted_class = result.get("class", "Unknown").strip().lower()
                    confidence = result.get("confidence")

                    # Debug raw output
                    st.text(f"🔍 Predicted Class (Raw): {predicted_class}")

                    # Map to category
                    category = CATEGORY_MAP.get(predicted_class, "Uncategorized Waste")

                    # Display result
                    st.markdown(f"""
                    ### 🗑️ Waste Type: **{category}**
                    {'✅ Confidence: {:.2f}%'.format(confidence * 100) if confidence is not None else ''}
                    """)
                except requests.exceptions.JSONDecodeError as e:
                    st.error(f"⚠️ Failed to parse JSON response: {e}")
            else:
                st.error(f"❌ Server returned status code {response.status_code}")
                st.text(response.text)

        except requests.exceptions.ConnectionError as e:
            st.error(f"⚠️ Could not connect to the FastAPI server. Make sure it is running.\n\nDetails: {e}")
        except requests.exceptions.RequestException as e:
            st.error(f"⚠️ Request failed: {e}")
